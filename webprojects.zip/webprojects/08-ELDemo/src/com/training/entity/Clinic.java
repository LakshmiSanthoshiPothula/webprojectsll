package com.training.entity;

public class Clinic {
	
String city="chennai";
String location="sholangivellur";
String phoneNumber="7864845887";
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}


}
